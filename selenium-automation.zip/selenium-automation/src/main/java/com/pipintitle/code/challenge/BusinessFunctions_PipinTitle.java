package com.pipintitle.code.challenge;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Date;
import java.util.TimeZone;
import java.util.UUID;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

public class BusinessFunctions_PipinTitle extends DriverClass {

	static WebDriverWait wait = null;

	public WebDriverWait webDriverWait(long timeOutInSec) {
		try {
			wait = new WebDriverWait(driver, timeOutInSec);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return wait;
	}

	public void waitForElementToBeClickable(long timeOutInSec, By locator) {
		try {
			wait = new WebDriverWait(driver, timeOutInSec);
			wait.until(ExpectedConditions.elementToBeClickable(locator));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public String getTimeStamp(String strFormat, String strTimeZone) {
		try {
			DateFormat dateFormat = new SimpleDateFormat(strFormat);
			dateFormat.setTimeZone(TimeZone.getTimeZone(strTimeZone));
			String timeStamp = dateFormat.format(new Date());
			return timeStamp;
		} catch (Exception e) {
			return null;
		}
	}

	public void javaScriptClick(By locator, String locatorName) throws Throwable {
		try {
			WebElement element = driver.findElement(locator);
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", element);
			SuccessReport("Clicked on: " + locatorName);
		} catch (Exception e) {
			failureReport("Failed to click on:" + locatorName + "; Exception: " + e.getMessage());
			e.printStackTrace();
		}
	}

	public void click(By locator, String locatorName) throws Throwable {
		try {
			driver.findElement(locator).click();
			SuccessReport("Clicked on: " + locatorName);
		} catch (Exception e) {
			failureReport("Failed to click on:" + locatorName + "; Exception: " + e.getMessage());
			e.printStackTrace();
		}
	}

	public void type(By locator, String data, String locatorName) throws Throwable {
		try {
			driver.findElement(locator).clear();
			driver.findElement(locator).sendKeys(data);
			SuccessReport("Data is entered successfully in: " + locatorName + " with data " + data);
		} catch (Exception e) {
			failureReport(
					"Failed to enter data in:" + locatorName + " with data " + data + "; Exception: " + e.getMessage());
			e.printStackTrace();
		}
	}

	public void typeWithoutClear(By locator, String data, String locatorName) throws Throwable {
		try {
			driver.findElement(locator).sendKeys(data);
			SuccessReport("Data is entered successfully in: " + locatorName + " with data " + data);
		} catch (Exception e) {
			failureReport(
					"Failed to enter data in:" + locatorName + " with data " + data + "; Exception: " + e.getMessage());
			e.printStackTrace();
		}
	}

	public void moveToElement(By locator) {
		try {
			WebElement element = driver.findElement(locator);
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].scrollIntoView(true);", element);
			Thread.sleep(2000);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void pageLoadingCompleted() {
		try {
			wait = webDriverWait(60);
			wait.until(ExpectedConditions.invisibilityOfElementLocated(ObjectRepository.PAGE_LOADING_ICON));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void progressBarCompleted() {
		try {
			Wait<WebDriver> wait = new FluentWait<WebDriver>(driver).pollingEvery(Duration.ofSeconds(2))
					.ignoring(NoSuchElementException.class).withTimeout(Duration.ofSeconds(30));
			wait.until(ExpectedConditions.invisibilityOfElementLocated(ObjectRepository.PROGRESS_BAR));
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void waitForElementPresent(By locator) {
		try {
			Wait<WebDriver> wait = new FluentWait<WebDriver>(driver).pollingEvery(Duration.ofSeconds(2))
					.ignoring(NoSuchElementException.class).withTimeout(Duration.ofSeconds(30));
			wait.until(ExpectedConditions.presenceOfElementLocated(locator));
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void login(String strUserName, String strPassword) throws Throwable {
		try {
			type(ObjectRepository.EMAIL_ADDR_TEXTFIELD, strUserName, "User Name Text Field");
			type(ObjectRepository.PASSWORD_TEXTFIELD, strPassword, "Password Text Field");
			click(ObjectRepository.LOGIN_BTN, "Login Button");
			pageLoadingCompleted();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void clickOnPlaceOrder() throws Throwable {
		try {
			click(ObjectRepository.PLACE_ORDER_BTN, "Place Order Button");
			pageLoadingCompleted();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void selectProduct(String strProduct) throws Throwable {
		try {
			click(By.xpath(ObjectRepository.getCommonProductsRadioButton(strProduct)), strProduct + " Radio Button");
			pageLoadingCompleted();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void searchCriteria(String strOwner_Seller_Name, String addressType, String propertySearchValue,
			String clientReference) throws Throwable {
		try {
			type(ObjectRepository.OWNER_SELLER_TEXTFIELD, strOwner_Seller_Name, "Owner/Seller Text Field");
			switch (addressType) {
			case "Auto Complete": // Assuming Autom Complete is selected by default
				moveToElement(ObjectRepository.OWNER_SELLER_TEXTFIELD);
				type(ObjectRepository.PROPERTY_SEARCH_TEXTFIELD, propertySearchValue, "Property Search Text Field");
				waitForElementPresent(By.xpath(ObjectRepository.PROPERTY_SEARCH_RESULTS));
				waitForElementToBeClickable(5,
						By.xpath(ObjectRepository.PROPERTY_SEARCH_RESULTS + "[2]/span[@class='pac-item-query']"));
				click(By.xpath(ObjectRepository.PROPERTY_SEARCH_RESULTS + "[2]/span[@class='pac-item-query']"),
						"Search Results");
				pageLoadingCompleted();
				type(ObjectRepository.CLIENT_REF_NUM_TEXTFIELD, clientReference, "Client Reference Text Field");
				break;
			case "Manual Entry":
				break;
			default:
				break;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void fileUpload(String fileNames, String filePath) throws Throwable {
		try {
			String files = "";
			String[] arrayFileNames = fileNames.split(",");
			for (int i = 0; i < arrayFileNames.length; i++) {
				if (i == arrayFileNames.length - 1) {
					files += filePath.concat(arrayFileNames[i]);
				} else {
					files += filePath.concat(arrayFileNames[i]).concat("\n ");
				}
			}
			waitForElementPresent(ObjectRepository.FILE_UPLOAD_FIELD);
			typeWithoutClear(ObjectRepository.FILE_UPLOAD_FIELD, files, "Upload Document");
			progressBarCompleted();
			pageLoadingCompleted();
			int rowCount = driver.findElements(By.xpath(ObjectRepository.DOCUMENTS_ROWS)).size();
			if (rowCount == arrayFileNames.length) {
				SuccessReport("File Uploaded Successfully");
			} else {
				failureReport("Files not uploaded");
				throw new Exception("Files not uploaded");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void signOut() throws Throwable {
		try {
			click(ObjectRepository.USER_PROFILE_ICON, "User Profile Icon");
			click(ObjectRepository.LOG_OUT_LINK, "Logout Link");
			pageLoadingCompleted();
			waitForElementPresent(ObjectRepository.LOGIN_BTN);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void deleteFiles(int deleteCount) throws Throwable {
		try {
			int rowCount = driver.findElements(By.xpath(ObjectRepository.DOCUMENTS_ROWS)).size();
			for (int i = 1; i < rowCount; i++) {
				click(By.xpath(ObjectRepository.DOCUMENTS_ROWS + "[1]//i[contains(text(),'delete')]"), "Delete Icon");
				waitForElementPresent(ObjectRepository.CONFIRM_BTN_MODAL_DIALOG);
				click(ObjectRepository.CONFIRM_BTN_MODAL_DIALOG, "Confirm Button");
				pageLoadingCompleted();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void placeOrder() throws Throwable {
		try {
			javaScriptClick(ObjectRepository.ACCEPT_TERMS_CONDITION_CHECKBOX, "I Accept terms and condition checkbox");
			pageLoadingCompleted();
			click(ObjectRepository.SUBMIT_BTN, "Submit Button");
			pageLoadingCompleted();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void sendMessage(String name) throws Throwable {
		try {
			String orderNumber = driver.findElement(ObjectRepository.ORDER_NUMBER_TEXTFIELD).getAttribute("value");
			SuccessReport("Order is creates successfully: "+ orderNumber);
			click(ObjectRepository.MESSAGE_BTN, "Message Button");
			waitForElementPresent(ObjectRepository.TEXT_AREA_MODAL_DIALOG);
			String message = name.concat(",").concat(orderNumber).concat(",")
					.concat(getTimeStamp("MM/dd/yyyy HH:mm:ss", "IST"));
			type(ObjectRepository.TEXT_AREA_MODAL_DIALOG, message, " Text Area");
			click(ObjectRepository.SEND_BTN_MODAL_DIALOG, "Send Button");
			pageLoadingCompleted();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void SuccessReport(String strStepName) throws Throwable {
		test.log(Status.PASS, strStepName);
	}

	public void failureReport(String strStepDes) throws Throwable {
		test.log(Status.FAIL, strStepDes);
		test.addScreenCaptureFromPath(screenShotForPass(driver));
	}

	public String screenShotForPass(WebDriver driver) throws IOException {
		String src_path = "";
		src_path = System.getProperty("user.dir") + "\\reports\\Screenshots\\";
		UUID uuid = UUID.randomUUID();
		// generate screenshot as a file object
		File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		try {
			// copy file object to designated location
			FileUtils.copyFile(scrFile, new File(src_path + uuid + ".png"));
		} catch (IOException e) {
			System.out.println("Unhadled exception occure while generating screenshot:\n" + e.toString());
		}
		return src_path + uuid + ".png";
	}

}
