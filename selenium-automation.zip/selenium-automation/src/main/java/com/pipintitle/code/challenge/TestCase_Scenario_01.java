package com.pipintitle.code.challenge;

import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

public class TestCase_Scenario_01 extends BusinessFunctions_PipinTitle {

	public String fileNames = "file1.pdf,file2.pdf,file3.pdf";
	WebDriverWait wait = null;

	@Test
	public void testCaseScenario_01() throws Throwable {
		test = extent.createTest("Order Creation");

		// Login to the application
		login("pippintitle_demotest@mailinator.com", "DemoTest#567#");
		// Click on the Place Order Button
		clickOnPlaceOrder();
		// Select Product
		selectProduct("Full Search");
		// Search Criteria
		searchCriteria("Akhilesh Swamy", "Auto Complete", "3485 Wineville", "Akhilesh Swamy_20_07_1987");
		// File Upload
		String filePath = System.getProperty("user.dir") + "//testdata//";
		fileUpload(fileNames, filePath);
		// Delete Files
		deleteFiles(2);
		// Click on Continue Button
		click(ObjectRepository.CONTINUE_BTN, "Continue Button");
		pageLoadingCompleted();
		// Place Order
		placeOrder();
		// Click on the Message Button
		sendMessage("Akhilesh Swamy");
		// Sign out
		signOut();

	}
}
