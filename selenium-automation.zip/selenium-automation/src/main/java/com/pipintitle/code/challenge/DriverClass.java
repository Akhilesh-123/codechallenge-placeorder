package com.pipintitle.code.challenge;

import java.io.IOException;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

import io.github.bonigarcia.wdm.WebDriverManager;

public class DriverClass {

	public static ExtentHtmlReporter htmlReporter;
	public static ExtentReports extent;
	public static ExtentTest test;
	public static EventFiringWebDriver driver;
	public static WebDriver webDriver;

	@Parameters({ "browser" })
	@BeforeTest
	public void startTest(String browser) {
		htmlReporter = new ExtentHtmlReporter(System.getProperty("user.dir") + "//reports//ExtentReport.html");
		extent = new ExtentReports();
		extent.attachReporter(htmlReporter);
		extent.setSystemInfo("User Name", "Akhilesh Swamy");
		htmlReporter.config().setDocumentTitle("Pippin Title");
		htmlReporter.config().setReportName("Pippin Title");
		// Dark Theme
		htmlReporter.config().setTheme(Theme.STANDARD);

		if (browser.equalsIgnoreCase("Chrome")) {
			WebDriverManager.chromedriver().setup();
			webDriver = new ChromeDriver();
		} else if (browser.equalsIgnoreCase("Firefox")) {
			WebDriverManager.firefoxdriver().setup();
			webDriver = new FirefoxDriver();
		} else if (browser.equalsIgnoreCase("Edge")) {
			WebDriverManager.edgedriver().setup();
			webDriver = new EdgeDriver();
		}
		MyListener eCapture = new MyListener();
		driver = new EventFiringWebDriver(webDriver);
		driver.register(eCapture);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
		driver.get("https://demo.pippintitle.com/");

	}

	@AfterTest
	public void endTest() throws IOException {
		Runtime.getRuntime().exec("taskkill /F /IM IEDriverServer.exe");
		Runtime.getRuntime().exec("taskkill /im chromedriver.exe /f");
		extent.flush();
		driver.close();
		driver.quit();
	}

}
