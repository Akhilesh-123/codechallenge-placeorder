package com.pipintitle.code.challenge;

import org.openqa.selenium.By;

public class ObjectRepository {

	//Common Elements
	public static final By PAGE_LOADING_ICON=By.xpath("//mat-spinner");
	public static final String SPAN_TEXT="//span[contains(text(),'";
	public static final By USER_PROFILE_ICON=By.xpath("//icon[@icon='arrow_drop_down']/i");
	public static final By LOG_OUT_LINK=By.xpath("//button[contains(text(),'Logout')]");
	public static final By PROGRESS_BAR=By.xpath("//mat-progress-bar");
	
	
	
	//Login Screen
	public static final By EMAIL_ADDR_TEXTFIELD=By.id("Email_Address");
	public static final By PASSWORD_TEXTFIELD=By.id("User_Password");
	public static final By LOGIN_BTN=By.id("loginBtnLogin");
	
	//Login Screen
	public static final By PLACE_ORDER_BTN=By.xpath("//a//strong[text()='Place Order']");
	
	//Place New Order Screen
	public static final By OWNER_SELLER_TEXTFIELD=By.id("Property_First_Name");
	public static final By PROPERTY_SEARCH_TEXTFIELD=By.id("search-box");
	public static final By CLIENT_REF_NUM_TEXTFIELD=By.id("Property_Order_Number");
	public static final By FILE_UPLOAD_FIELD=By.id("file-upload");
	public static final String PROPERTY_SEARCH_RESULTS="//div[@class='pac-container pac-logo hdpi']/div";
	public static final String DOCUMENTS_ROWS="//label[text()='Documents']/following-sibling::div/div";
	public static final By CONTINUE_BTN=By.xpath("//button[contains(text(),'Continue')]");
	public static final By ACCEPT_TERMS_CONDITION_CHECKBOX=By.xpath("//span[contains(text(),'I accept the')]/preceding-sibling::mat-checkbox/label");
	
	
	//Get the Common Products
	public static String getCommonProductsRadioButton(String strProduct) {
		return SPAN_TEXT+strProduct+"')]/parent::div/preceding-sibling::div";
	}
	
	
	//Place New Order Screen - Review Order Screen
	public static final By SUBMIT_BTN=By.xpath("//button[contains(text(),'Submit')]");
	
	//Order Details Screen
	public static final By MESSAGE_BTN=By.xpath("//input[@value='Message']");
	public static final By ORDER_NUMBER_TEXTFIELD=By.id("Order_ID");
	
	
	//Modal Dialog
	public static final By TEXT_AREA_MODAL_DIALOG=By.xpath("//div[@class='modal-dialog']//textarea");
	public static final By CONFIRM_BTN_MODAL_DIALOG=By.xpath("//div[@class='modal-dialog']//input[@value='Confirm']");
	public static final By SEND_BTN_MODAL_DIALOG=By.xpath("//div[@class='modal-dialog']//input[@value='Send']");
	
	
	
	
}
